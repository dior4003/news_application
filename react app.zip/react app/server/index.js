const express = require('express');
const mongoose = require('mongoose');
const User =require('./models/user');
const bcrypt =require('bcrypt');
const app= express();

mongoose.connect('mongodb+srv://diyor:ehfbkdcYFTYFchs@cluster0.mde2j.mongodb.net/mini-project');

app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.post('/signup', (req , res)=>{
    const {name , email , password}=req.body;
    if(!name||!email||!password){
        res.status(400).json({
            message:"Pleasw fill all the fields"
        });
    }
    User.findOne({email})
        .then(savedUser=>{
            if(savedUser){
                return res.status(400).json({error:"User already exists"});
            }
            bcrypt.hash(password , 10)
            .then(hash=>{
                const User = new User({
                    name:name,
                    email:email,
                    password:hash
                });
            })
           
            User.save()
            .then((User)=>{
                res.json({
                    message:"user create succesfully",
                    User
                })
            })
            .catch(err=>{
                console.log(err);
            });
        });
    
});


app.listen(5000 ,()=>{
    console.log('server start')
})

//parolim: ehfbkdcYFTYFchs