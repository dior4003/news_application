import React from 'react'
import Nav from './components/ui/navbar'
import FooterDiv from './components/ui/footer'
import {usePosts} from './components/ui/useCreatePosts'
import {Routes , Route} from 'react-router-dom'
import {useState} from 'react'
import MyApp from './home'
import Login from './components/ui/login'


function App() {

  const [posts , setPosts] = useState([
    {id:1, picture:"https://avatars.mds.yandex.net/get-altay/2022045/2a0000016c995a8bbf88f22e845a4f875cc4/XXL" , title:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam nesciunt ipsum vitae numquam ut voluptas totam natus omnis impedit nemo?"},
    {id:2, picture:"https://avatars.mds.yandex.net/get-altay/2022045/2a0000016c995a8bbf88f22e845a4f875cc4/XXL" , title:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam nesciunt ipsum vitae numquam ut voluptas totam natus omnis impedit nemo?"},
    {id:3, picture:"https://avatars.mds.yandex.net/get-altay/2022045/2a0000016c995a8bbf88f22e845a4f875cc4/XXL" , title:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam nesciunt ipsum vitae numquam ut voluptas totam natus omnis impedit nemo?"},
    {id:4, picture:"https://avatars.mds.yandex.net/get-altay/2022045/2a0000016c995a8bbf88f22e845a4f875cc4/XXL" , title:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam nesciunt ipsum vitae numquam ut voluptas totam natus omnis impedit nemo?"},
    {id:5, picture:"https://avatars.mds.yandex.net/get-altay/2022045/2a0000016c995a8bbf88f22e845a4f875cc4/XXL" , title:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam nesciunt ipsum vitae numquam ut voluptas totam natus omnis impedit nemo?"},
    {id:6, picture:"https://avatars.mds.yandex.net/get-altay/2022045/2a0000016c995a8bbf88f22e845a4f875cc4/XXL" , title:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam nesciunt ipsum vitae numquam ut voluptas totam natus omnis impedit nemo?"},
  ])
  const [filter , setFilter]=useState({sort:"", query:""})
  const [modal , setModal]=useState(false)
  const SortedAndSearchPosts = usePosts(posts ,filter.sort ,filter.query)
  const createPost=(newPost)=>{
    setPosts([...posts,newPost]) 
    setModal(false)}
    const removePost=(post)=>{setPosts(posts.filter(s=> s.id!==post.id))}
      
  
 
  return (
    <>
      <Nav/>
      <Routes>
        <Route path="/" exact element={<MyApp/>}/>
        <Route path="/signup" element={<Login/>}/>
      </Routes>
      
      <FooterDiv/>
   </>
  )
}

export default App
