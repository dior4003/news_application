import axios from "axios"

class PostServisApi{
    static async getAllPosts(limit=10 , page= 1){
        const response = await axios.get("https://newsapi.org/v2/top-headlines? manbalar=techcrunch &apiKey=63307084a31e430f9d09b49c05741162" ,{
        params: {
            _limit: limit,
            _page: page
        }
        })
        
        return response
    }
}

export default PostServisApi