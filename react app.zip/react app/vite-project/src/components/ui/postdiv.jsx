import React from 'react'
import { useState } from 'react'
import PostItem from './post'

const PostDiv=({posts , remov })=>{
    
    

    return(
        <>
            <div class="album py-5 bg-light">
                <div class="container">
                    <div class="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                       
                    {posts.map((item ,index)=>(
                        <PostItem post={item} key={item.id} remove={remov} num={index+1} />
                    ))}
                    </div>
                </div>
            </div>
        </>

    )
}
export default PostDiv