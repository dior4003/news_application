import React from "react"

const title=(props)=>{
    return(
        <p className="card-text">{props.title}</p>
    )
}

export default title