import { useEffect } from "react"


export default function signUp(){

    return(
        <>
            <div className="container-fluit">
            
            </div>
        </>
    )
}