import React from 'react'
import MyInput from './componet/myInput'
import MyButton from './componet/button'
import { useRef } from 'react'
import { useState } from 'react'

export default function PostForm({createPost}){
    const [post , setPost]=useState({title:"", picture:""})
  

    const addPost = (e)=>{
        e.preventDefault()
        const newPost={
            ...post,
            id:Date.now()
        }
        createPost(newPost)
        setPost({title:"", picture:""})

    }
    return(
      <>
        <h3 className="text text-center">Craete your first post</h3>
        <form>
          <MyInput 
          className="form-control my-2"
          type="text" 
          placeholder="Programming language" 
          value={post.title}
          onChange={e=>setPost({...post , title: e.target.value})}
          />
          <MyInput 
          className="form-control my-2"
          type="text" 
          placeholder="Enter your favorite stack"
          value={post.picture}
          onChange={e=>setPost({...post , picture: e.target.value})} 
          />
          {/* <MyInput 
          className="form-control my-2"
          type="file" 
          accept=".jpg, .jpeg, .png" 
          multiple
          placeholder="Enter your favorite stack"
          value={post.picture}
          onChange={e=>setPost({...post , picture: e.target.value})} 
          /> */}
          <MyButton onClick={addPost} className="btn btn-primary w-100">Add post</MyButton>
        </form>
      </>
        
    )
}