import '../../css/bootstrap.css'
import React from 'react'
export default function FooterDiv(){

    return(
        <>
           <footer className="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
                <div className="col-md-4 justify-content-center d-flex align-items-center">
                
                <span className="text-muted">© 2021 Company, Inc</span>
                </div>

                <ul className="nav col-md-4 justify-content-center list-unstyled d-flex">
                <li className="ms-3"><i className="bi bi-instagram text-danger"></i></li>
                <li className="ms-3"><i className="bi bi-facebook text-info"></i></li>
                <li className="ms-3"><i className="bi bi-telegram text-info"></i></li>
                </ul>
            </footer>
           
        </>
    )
}