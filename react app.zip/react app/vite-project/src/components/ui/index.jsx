import '../../css/content.css'
import PostForm from './postForm'
export default function Content(){
    return(
        <>
            <main>

                <section class="tdtu  text-center container-fluit">
                <div class="tdtu1 row py-lg-5">
                    <div class="col-lg-6 col-md-8 mx-auto">
                    <h1 class="fw-light text-white">Album example</h1>
                    <p class=" text-light">Something short and leading about the collection below—its contents, the creator, etc. Make it short and sweet, but not too short so folks don’t simply skip over it entirely.</p>
                    <p>
                        <a href="#" class="btn btn-secondary my-2">Secondary action</a>
                    </p>
                    </div>
                </div>
                </section>

               

            </main>
        </>
    )
}