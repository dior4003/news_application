---
title: Check square fill
layout: icon
categories:
  - Alerts, warnings, and signs
tags:
  - checkmark
  - confirm
  - done
---
